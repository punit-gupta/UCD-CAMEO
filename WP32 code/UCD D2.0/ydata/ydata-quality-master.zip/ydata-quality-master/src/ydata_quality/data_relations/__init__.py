"""
Tools to check dataset for data relations.
"""
from .engine import DataRelationsDetector

__all__ = [
    "DataRelationsDetector"
]
